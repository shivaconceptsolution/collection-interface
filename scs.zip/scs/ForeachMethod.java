package com.scs;

import java.util.ArrayList;

public class ForeachMethod {
    public static void main(String[] args) {
        String arr[] = {"C","CPP","DS","JAVA","PHP",".NET","iOS"};
        ArrayList obj = new ArrayList();
        for(Object o:arr)
        {
            obj.add(o);
        }
     /*   obj.add("C");
        obj.add("CPP");
        obj.add("DS");
        obj.add("Java");*/

        obj.forEach(
                item -> System.out.println(item)

        );
    }

}
