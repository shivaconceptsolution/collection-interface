    package com.scs;

    interface A
    {
        public int fun(int x, int y);
    }



    public class LamdaExpression {
        public static void main(String[] args) {
            A obj = (int x,int y) -> {
                   return x+y;
            };

            System.out.println(obj.fun(100,20));



        }
    }
