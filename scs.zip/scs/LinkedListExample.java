package com.scs;

import java.util.LinkedList;

public class LinkedListExample {
    public static void main(String[] args) {
        LinkedList<String> lst =new LinkedList<String>();
        lst.add("C");
        lst.add("CPP");
        lst.add("DS");
        lst.addFirst("Java");
        lst.addLast("PHP");

        for(String s:lst)
        {
            System.out.println(s);
        }
    }
}
