package com.scs;
import java.util.*;
public class Main {

    public static void main(String[] args) {
	/*   ArrayList obj = new ArrayList();
	   obj.add(10);
	   obj.add(20);
	   obj.add("C");
	   obj.add("CPP");
	   obj.add(12.345F);
	   obj.remove("C");
	   for(Object o :obj)
        {
            System.out.println(o);
        }
	   for (int i=0;i<obj.size();i++)
	   {
	   	  System.out.println(obj.get(i));
	   }
	   System.out.print("Elements of ArrayList are");
	   Iterator i = obj.iterator();
	   while(i.hasNext())
	   {
	   	 Object o = i.next();
	   	 System.out.println(o);
	   }

	   System.out.println("ArrayList Elements in Forward Direction ");
	   ListIterator lst = obj.listIterator();
		while(lst.hasNext())
		{
			Object o = lst.next();
			System.out.println(o);
		}
		System.out.println("ArrayList Elements in BackWard Direction ");
		while(lst.hasPrevious())
		{
			Object o = lst.previous();
			System.out.println(o);
		}*/

		ArrayList<Product> pr = new ArrayList<Product>();
		pr.add(new Product(1001,"XYZ"));
        pr.add(new Product(1002,"XYZ123"));
       // System.out.println(pr);
        for(Product p:pr)
        {
            System.out.println(p.getProductid() + " "+ p.getProductname());
        }

        Iterator it = pr.iterator();
        while(it.hasNext())
        {
            Product p = (Product) it.next();
            System.out.println(p.getProductid() + " "+p.getProductname() + " ");
        }

    }
}
