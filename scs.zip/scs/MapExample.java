package com.scs;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.*;
import java.util.Set;

public class MapExample
{

    public static void main(String[] args) {
     //   Map<String,String> mp = new HashMap<String,String>();
     //   Map<String,String> mp = new LinkedHashMap<String,String>();
     //   Map<String,String> mp = new TreeMap<String,String>();
        Map<String,Product> mp = new TreeMap<String,Product>();
        mp.put("A",new Product(1001,"XYZ"));
        mp.put("D",new Product(1001,"ABC"));
        mp.put("C",new Product(1001,"MNO"));
        mp.put("E",new Product(1001,"KLMN"));
        mp.put("B",new Product(1001,"JPG"));
       // mp.put(null,"1008");

        Set<Map.Entry<String,Product>> se = mp.entrySet();
        for(Map.Entry<String,Product> me:se)
        {
            System.out.println(me.getKey() + " "+me.getValue());
        }

        System.out.println(se);
        System.out.println(mp.values());
        for(Object o:mp.values())
        {
            System.out.println(o);
        }



    }
}
