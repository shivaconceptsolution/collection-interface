package com.scs;

public class Product {
    private int productid;
    private  String productname;
    Product(int productid, String productname)
    {
        this.productid=productid;
        this.productname=productname;
    }
    public int getProductid() {
        return productid;
    }

    public void setProductid(int productid) {
        this.productid = productid;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public  String toString()
    {
        return "PID is "+productid + " Name is "+productname;
    }
}
