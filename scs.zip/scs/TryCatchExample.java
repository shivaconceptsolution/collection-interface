package com.scs;

public class TryCatchExample {
    public static void main(String[] args) {
        try
        {
            System.out.println("hello");
            try {
                System.out.println("hi");
            }
            finally {

            }
        }
        finally {

        }
    }
}
