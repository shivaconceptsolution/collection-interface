package com.scs;

import java.util.Vector;

public class VectorStackExample {
    public static void main(String[] args) {
        Vector<Integer> v = new Vector<Integer>();
        v.add(101);
        v.add(105);
        v.add(109);
        v.add(1023);
        for(Integer a:v)
        {
            System.out.println(a);
        }

    }
}
